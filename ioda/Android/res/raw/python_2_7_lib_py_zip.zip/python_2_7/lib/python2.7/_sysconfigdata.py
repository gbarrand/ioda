# system configuration generated and used by the sysconfig module
# G.Barrand : we empty it.
build_time_vars = {}
